package com.farhandevops.skyway.services;

import java.util.Random;

public class PaymentService {
    // PaymentResult ek nested class hai jo payment ka result store karti hai.
    public static class PaymentResult {
        public boolean success; // Payment successful tha ya nahi.
        public String transactionId; // Unique transaction ID.

        // Constructor to set payment result.
        public PaymentResult(boolean success, String transactionId) {
            this.success = success;
            this.transactionId = transactionId;
        }
    }

    // processPayment method ek payment process karta hai aur result return karta hai.
    public static PaymentResult processPayment(
            double amount,
            String cardNumber,
            String cvv,
            String expiryDate
    ) {
        // Card details ki validation karta hai.
        if (!validateCardDetails(cardNumber, cvv, expiryDate)) {
            return new PaymentResult(false, null); // Agar validation fail ho, toh false return karega.
        }

        // Payment processing simulate karte hain.
        try {
            Thread.sleep(2000); // 2 second ka delay simulate karta hai.

            // Random success/failure (90% success rate).
            boolean paymentSuccess = new Random().nextDouble() < 0.9;

            // Agar payment successful ho, toh transaction ID generate karta hai.
            return paymentSuccess
                    ? new PaymentResult(true, generateTransactionId())
                    : new PaymentResult(false, null);
        } catch (InterruptedException e) {
            return new PaymentResult(false, null); // Agar exception ho, toh false return karta hai.
        }
    }

    // validateCardDetails method card details ki validation karta hai.
    private static boolean validateCardDetails(
            String cardNumber,
            String cvv,
            String expiryDate
    ) {
        // Comprehensive card validation.
        return cardNumber != null &&
                cardNumber.length() == 16 && // Card number 16 digits ka hona chahiye.
                cvv != null &&
                cvv.length() == 3; // CVV 3 digits ka hona chahiye.
    }

    // generateTransactionId method ek unique transaction ID generate karta hai.
    private static String generateTransactionId() {
        return "TXN" + System.currentTimeMillis(); // Unique ID jo system time par base hoti hai.
    }
}
