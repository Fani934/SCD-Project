package com.farhandevops.skyway;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CheckStatusActivity extends AppCompatActivity {

    private EditText bookingReferenceInput;
    private Button checkStatusButton;
    private TextView statusOutput, departureTime, seatInfo;
    private LinearLayout statusContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_status);

        bookingReferenceInput = findViewById(R.id.booking_reference_input);
        checkStatusButton = findViewById(R.id.check_status_button);
        statusOutput = findViewById(R.id.status_output);
        departureTime = findViewById(R.id.departure_time);
        seatInfo = findViewById(R.id.seat_info);
        statusContainer = findViewById(R.id.status_container);

        // Promo banner setup
        TextView promoBanner = findViewById(R.id.promo_banner);
        promoBanner.setText("Track Your Flight Status");

        checkStatusButton.setOnClickListener(v -> {
            String bookingReference = bookingReferenceInput.getText().toString().trim();

            if (bookingReference.isEmpty()) {
                Toast.makeText(CheckStatusActivity.this, "Please enter a booking reference", Toast.LENGTH_SHORT).show();
            } else {
                // Simulate backend API call (replace with real API)
                String flightStatus = getFlightStatusFromBackend(bookingReference);
                updateFlightStatus(flightStatus);
            }
        });
    }

    private String getFlightStatusFromBackend(String bookingReference) {
        // Simulated backend call (replace with actual API request)
        if (bookingReference.equals("123ABC")) {
            return "on_time";
        } else {
            return "not_found";
        }
    }

    private void updateFlightStatus(String status) {
        if (status.equals("on_time")) {
            statusOutput.setText("Flight Status: On Time");
            statusOutput.setTextColor(getResources().getColor(R.color.successColor));
            departureTime.setText("Departure: 10:00 AM");
            seatInfo.setText("Seat: 12A");
            statusContainer.setVisibility(View.VISIBLE);
        } else {
            statusOutput.setText("Flight not found");
            statusOutput.setTextColor(getResources().getColor(R.color.errorColor));
            statusContainer.setVisibility(View.GONE);
        }
    }
}
