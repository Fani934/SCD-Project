package com.farhandevops.skyway.tests;

import static org.junit.jupiter.api.Assertions.*;

import com.farhandevops.skyway.models.Customer;
import com.farhandevops.skyway.models.Ticket;
import com.farhandevops.skyway.services.AnalyticsService;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

public class AnalyticsServiceTest {

    @Test
    public void testAnalytics() {
        List<Ticket<?>> tickets = new ArrayList<>();

        // Create mock data for tickets
        Customer customer1 = new Customer.Builder()
                .setCustomerId("C001")
                .setName("Farhan Mehmood")
                .setEmail("farhanmehmood023@gmail.com")
                .setPhone("1234567890")
                .build();

        Customer customer2 = new Customer.Builder()
                .setCustomerId("C002")
                .setName("jason Smith")
                .setEmail("jason.smith@example.com")
                .setPhone("9876543210")
                .build();

        tickets.add(new Ticket.Builder<>()
                .setTicketId("T001")
                .setFlightId("FL123")
                .setPassengerInfo(customer1)
                .setPrice(299.99)
                .build());

        tickets.add(new Ticket.Builder<>()
                .setTicketId("T002")
                .setFlightId("FL123")
                .setPassengerInfo(customer2)
                .setPrice(299.99)
                .build());

        tickets.add(new Ticket.Builder<>()
                .setTicketId("T003")
                .setFlightId("FL456")
                .setPassengerInfo(customer1)
                .setPrice(199.99)
                .build());

        AnalyticsService analytics = new AnalyticsService();

        // Test total revenue
        assertEquals(799.97, analytics.calculateTotalRevenue(tickets));

        // Test most booked flight
        assertEquals("FL123", analytics.findMostBookedFlight(tickets));

        // Test most frequent customer
        assertEquals(customer1.toString(), analytics.findMostFrequentCustomer(tickets));
    }
}
