package com.farhandevops.skyway.services;

import android.content.Context;
import android.content.SharedPreferences;

public class UserProfileService {

    private static final String PREFS_NAME = "UserProfilePrefs";
    private static final String KEY_NAME = "name";
    private static final String KEY_EMAIL = "email";

    // Save user profile information
    public static void saveUserProfile(Context context, String name, String email) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_NAME, name);
        editor.putString(KEY_EMAIL, email);
        editor.apply(); // Save changes asynchronously
    }

    // Retrieve user profile information
    public static String getUserProfile(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String name = sharedPreferences.getString(KEY_NAME, "No Name Available");
        String email = sharedPreferences.getString(KEY_EMAIL, "No Email Available");
        return "Name: " + name + "\nEmail: " + email;
    }

    // Clear user profile information (e.g., during logout)
    public static void clearUserProfile(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear(); // Remove all preferences
        editor.apply();
    }
}
