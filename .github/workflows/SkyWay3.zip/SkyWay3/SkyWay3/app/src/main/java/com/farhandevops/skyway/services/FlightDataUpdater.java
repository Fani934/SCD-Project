package com.farhandevops.skyway.services;

import com.farhandevops.skyway.models.Flight;

import java.time.LocalDateTime;
import java.util.List;

public class FlightDataUpdater implements Runnable {
    private final List<Flight> flights;

    public FlightDataUpdater(List<Flight> flights) {
        this.flights = flights;
    }

    @Override
    public void run() {
        while (true) { // Yeh loop continuously chalta rahega (Continuous execution ke liye infinite loop)
            try {
                // Simulate periodic updates every 5 seconds (5 second ke interval par data update)
                Thread.sleep(5000); // Yeh thread ko 5 seconds ke liye sleep karata hai (Thread sleep for 5 seconds)

                synchronized (flights) { // Synchronize access to the flight list (Flight list ka synchronized access)
                    for (Flight flight : flights) {
                        // Update departure time to current time + 3 hours (Departure time ko update karna)
                        System.out.println("Updating flight: " + flight.getFlightId());
                        LocalDateTime newDepartureTime = LocalDateTime.now().plusHours(3);
                        LocalDateTime newArrivalTime = newDepartureTime.plusHours(2);

                        // Update flight details (recreate immutable object)
                        Flight updatedFlight = new Flight.Builder()
                                .setFlightId(flight.getFlightId())
                                .setOrigin(flight.getOrigin())
                                .setDestination(flight.getDestination())
                                .setDepartureTime(newDepartureTime)
                                .setArrivalTime(newArrivalTime)
                                .setTotalSeats(flight.getTotalSeats())
                                .build();

                        // Replace the flight in the list (Flight list mein updated flight replace karna)
                        flights.set(flights.indexOf(flights), updatedFlight);
                    }
                }

                System.out.println("Flight data updated successfully.");

            } catch (InterruptedException e) {
                // Exception handling when thread is interrupted (Thread interrupt hone par exception handling)
                System.out.println("Flight data updater interrupted: " + e.getMessage());
            }
        }
    }
}
