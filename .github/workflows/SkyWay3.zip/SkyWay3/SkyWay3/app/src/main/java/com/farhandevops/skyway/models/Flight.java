package com.farhandevops.skyway.models;

import java.time.LocalDateTime;

public final class Flight {
    // Immutable fields (immutable fields)
    private final String flightId; // Yeh field final hai, iski value change nahi ho sakti
    private final String origin; // Yeh field bhi final hai, value fixed rahegi
    private final String destination; // Destination ki value bhi immutable hai
    private final LocalDateTime departureTime; // Departure time ki value ko change nahi kiya jaa sakta
    private final LocalDateTime arrivalTime; // Arrival time bhi immutable hai
    private final int totalSeats; // Total seats ka value bhi change nahi ho sakta

    // Private constructor to prevent direct object creation (direct object creation ko prevent karne ke liye private constructor)
    private Flight(Builder builder) {
        this.flightId = builder.flightId;
        this.origin = builder.origin;
        this.destination = builder.destination;
        this.departureTime = builder.departureTime;
        this.arrivalTime = builder.arrivalTime;
        this.totalSeats = builder.totalSeats;
    }
    // Getter methods (sirf getter methods diye gaye hain, setters nahi diye gaye, isliye immutable hai)
    public String getFlightId() {
        return flightId;
    }
    public String getOrigin() {
        return origin;
    }
    public String getDestination() {
        return destination;
    }
    public LocalDateTime getDepartureTime() {
        return departureTime;
    }
    public LocalDateTime getArrivalTime() {
        return arrivalTime;
    }
    public int getTotalSeats() {
        return totalSeats;
    }
    // Builder Class for creating Flight objects (Flight objects banane ke liye builder class)
    public static class Builder {
        // Mutable fields for builder (builder ke liye mutable fields)
        private String flightId;
        private String origin;
        private String destination;
        private LocalDateTime departureTime;
        private LocalDateTime arrivalTime;
        private int totalSeats;

        // Setter methods for Builder class (Builder class ke liye setter methods)
        public Builder setFlightId(String flightId) {
            this.flightId = flightId;
            return this;
        }

        public Builder setOrigin(String origin) {
            this.origin = origin;
            return this;
        }

        public Builder setDestination(String destination) {
            this.destination = destination;
            return this;
        }

        public Builder setDepartureTime(LocalDateTime departureTime) {
            this.departureTime = departureTime;
            return this;
        }

        public Builder setArrivalTime(LocalDateTime arrivalTime) {
            this.arrivalTime = arrivalTime;
            return this;
        }

        public Builder setTotalSeats(int totalSeats) {
            this.totalSeats = totalSeats;
            return this;
        }

        // Build method to create an immutable Flight object (immutable Flight object create karne ke liye build method)
        public Flight build() {
            return new Flight(this);
        }
    }
}
