package com.farhandevops.skyway;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class FlightManagementActivity extends AppCompatActivity {

    private Button btnAddFlight, btnEditFlight, btnDeleteFlight, btnCheckFlights;
    private List<String> flightList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flight_management);

        btnAddFlight = findViewById(R.id.btn_add_flight);
        btnEditFlight = findViewById(R.id.btn_edit_flight);
        btnDeleteFlight = findViewById(R.id.btn_delete_flight);
        btnCheckFlights = findViewById(R.id.btn_check_flights);

        flightList = new ArrayList<>();
        populateHardcodedFlights(); // Populate the flight list with hardcoded data

        btnAddFlight.setOnClickListener(view -> showAddFlightDialog());
        btnEditFlight.setOnClickListener(view -> showFlightListDialog("Edit Flight"));
        btnDeleteFlight.setOnClickListener(view -> showFlightListDialog("Delete Flight"));
        btnCheckFlights.setOnClickListener(view -> showFlightListDialog("Check Flights"));
    }

    private void populateHardcodedFlights() {
        flightList.add("FL101 - 10:00 AM - 2025-01-11 - Monday");
        flightList.add("FL102 - 2:00 PM - 2025-01-12 - Tuesday");
        flightList.add("FL103 - 6:30 PM - 2025-01-13 - Wednesday");
        flightList.add("FL104 - 9:45 PM - 2025-01-14 - Thursday");
        flightList.add("FL105 - 8:00 AM - 2025-01-15 - Friday");
        flightList.add("FL106 - 11:30 AM - 2025-01-16 - Saturday");
        flightList.add("FL107 - 3:15 PM - 2025-01-17 - Sunday");
        flightList.add("FL108 - 7:45 PM - 2025-01-18 - Monday");
        flightList.add("FL109 - 9:00 AM - 2025-01-19 - Tuesday");
        flightList.add("FL110 - 12:00 PM - 2025-01-20 - Wednesday");
        flightList.add("FL111 - 4:30 PM - 2025-01-21 - Thursday");
        flightList.add("FL112 - 8:15 PM - 2025-01-22 - Friday");
        flightList.add("FL113 - 7:00 AM - 2025-01-23 - Saturday");
        flightList.add("FL114 - 1:00 PM - 2025-01-24 - Sunday");
        flightList.add("FL115 - 5:45 PM - 2025-01-25 - Monday");
        flightList.add("FL116 - 10:30 AM - 2025-01-26 - Tuesday");
        flightList.add("FL117 - 2:45 PM - 2025-01-27 - Wednesday");
        flightList.add("FL118 - 6:00 PM - 2025-01-28 - Thursday");
        flightList.add("FL119 - 9:30 PM - 2025-01-29 - Friday");
        flightList.add("FL120 - 8:00 AM - 2025-01-30 - Saturday");
        flightList.add("FL121 - 12:30 PM - 2025-01-31 - Sunday");
    }

    private void showAddFlightDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add Flight");

        final EditText flightNoInput = new EditText(this);
        flightNoInput.setHint("Flight Number");
        builder.setView(flightNoInput);
        final EditText flightNoInput2 = new EditText(this);
        flightNoInput2.setHint("Date:");
        builder.setView(flightNoInput);
        final EditText flightNoInput3 = new EditText(this);
        flightNoInput3.setHint("Time:");
        builder.setView(flightNoInput);
        final EditText flightNoInput4 = new EditText(this);
        flightNoInput4.setHint("Added by:");
        builder.setView(flightNoInput);
        final EditText flightNoInput5 = new EditText(this);
        flightNoInput5.setHint("Day:");
        builder.setView(flightNoInput);


        builder.setPositiveButton("Add", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                String flightNo = flightNoInput.getText().toString();
                if (!flightNo.isEmpty()) {
                    flightList.add(flightNo + " - 10:00 AM - 2025-01-11 - Monday");
                    Toast.makeText(FlightManagementActivity.this, "Flight Added", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(FlightManagementActivity.this, "Please enter a valid Flight Number", Toast.LENGTH_SHORT).show();
                }
            }
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void showFlightListDialog(String action) {
        CharSequence[] flightArray = flightList.toArray(new CharSequence[flightList.size()]);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle(action);

        builder.setItems(flightArray, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                String selectedFlight = flightList.get(which);
                if (action.equals("Edit Flight")) {
                    showEditFlightDialog(selectedFlight);
                } else if (action.equals("Delete Flight")) {
                    showDeleteFlightDialog(selectedFlight);
                } else {
                    Toast.makeText(FlightManagementActivity.this, selectedFlight, Toast.LENGTH_SHORT).show();
                }
            }
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void showEditFlightDialog(String flight) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Flight");

        final EditText flightInput = new EditText(this);
        flightInput.setText(flight);
        builder.setView(flightInput);

        builder.setPositiveButton("Update", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                String updatedFlight = flightInput.getText().toString();
                if (!updatedFlight.isEmpty()) {
                    int index = flightList.indexOf(flight);
                    flightList.set(index, updatedFlight);
                    Toast.makeText(FlightManagementActivity.this, "Flight Updated", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(FlightManagementActivity.this, "Please enter valid flight details", Toast.LENGTH_SHORT).show();
                }
            }
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void showDeleteFlightDialog(String flight) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete Flight");
        builder.setMessage("Are you sure you want to delete this flight?\n\n" + flight);

        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                flightList.remove(flight);
                Toast.makeText(FlightManagementActivity.this, "Flight Deleted", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("No", null);
        builder.show();
    }
}
