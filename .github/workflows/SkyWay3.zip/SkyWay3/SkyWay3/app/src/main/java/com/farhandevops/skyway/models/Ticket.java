package com.farhandevops.skyway.models;
public final class Ticket<T> {
    // Ticket class with generics T for flexibility in passenger information
    private final String ticketId; // Ticket ka unique ID
    private final String flightId; // Flight ka unique ID
    private final T passengerInfo; // Generics ka istemal for flexibility (Customer object ya string details ho sakti hain)
    private final double price; // Ticket ki price
    // Private constructor, sirf Builder class se accessible hai
    private Ticket(Builder<T> builder) {
        this.ticketId = builder.ticketId;
        this.flightId = builder.flightId;
        this.passengerInfo = builder.passengerInfo;
        this.price = builder.price;
    }
    // Ticket ID return karne ka method
    public String getTicketId() {
        return ticketId;
    }
    // Flight ID return karne ka method
    public String getFlightId() {
        return flightId;
    }
    // Passenger information return karne ka method, yeh generic type T hai
    public T getPassengerInfo() {
        return passengerInfo;
    }
    // Ticket price return karne ka method
    public double getPrice() {
        return price;
    }
    // Builder class with generics, Ticket objects create karne ke liye
    public static class Builder<T> {
        private String ticketId; // Builder ke andar ticket ID
        private String flightId; // Builder ke andar flight ID
        private T passengerInfo; // Builder ke andar passenger info, jo ke generic type T hai
        private double price; // Builder ke andar price
        // Builder method jo ticket ID set karta hai
        public Builder<T> setTicketId(String ticketId) {
            this.ticketId = ticketId;
            return this; // Current builder instance return karta hai for method chaining
        }
        // Builder method jo flight ID set karta hai
        public Builder<T> setFlightId(String flightId) {
            this.flightId = flightId;
            return this; // Current builder instance return karta hai for method chaining
        }
        // Builder method jo passenger info set karta hai
        public Builder<T> setPassengerInfo(T passengerInfo) {
            this.passengerInfo = passengerInfo;
            return this; // Current builder instance return karta hai for method chaining
        }
        // Builder method jo price set karta hai
        public Builder<T> setPrice(double price) {
            this.price = price;
            return this; // Current builder instance return karta hai for method chaining
        }
        // Method jo Ticket ka object create karta hai aur return karta hai
        public Ticket<T> build() {
            return new Ticket<>(this); // Naya Ticket object create karke return karta hai
        }
    }
}
