package com.farhandevops.skyway.tests;

import static org.junit.jupiter.api.Assertions.*;

import com.farhandevops.skyway.models.Customer;
import com.farhandevops.skyway.models.Flight;
import com.farhandevops.skyway.models.Flights;
import com.farhandevops.skyway.models.Ticket;
import com.farhandevops.skyway.services.AdvancedFilterService;
import com.farhandevops.skyway.services.ReportFilterService;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ReportFilterServiceTest {

    @Test
    public void testSearchTickets() {
        List<Ticket<?>> tickets = new ArrayList<>();

        // Create mock data for tickets
        Customer customer1 = new Customer.Builder()
                .setCustomerId("C001")
                .setName("John Doe")
                .setEmail("john.doe@example.com")
                .setPhone("1234567890")
                .build();

        tickets.add(new Ticket.Builder<>()
                .setTicketId("T001")
                .setFlightId("FL123")
                .setPassengerInfo(customer1)
                .setPrice(299.99)
                .build());

        // Create an instance of ReportFilterService and search for tickets
        ReportFilterService filterService = new ReportFilterService();
        List<Ticket<?>> foundTickets = filterService.searchTickets(tickets, "FL123");

        assertEquals(1, foundTickets.size());
    }

    @Test
    public void testAdvancedFilters() {
        List<Flight> flight = new ArrayList<>();

        // Create mock data for flights
        flight.add(new Flight.Builder()
                .setFlightId("FL123")
                .setOrigin("New York")
                .setDestination("Los Angeles")
                .setDepartureTime(LocalDateTime.now().plusHours(3))
                .setArrivalTime(LocalDateTime.now().plusHours(6))
                .setTotalSeats(100)
                .build());

        flight.add(new Flight.Builder()
                .setFlightId("FL456")
                .setOrigin("London")
                .setDestination("Paris")
                .setDepartureTime(LocalDateTime.now().plusHours(1))
                .setArrivalTime(LocalDateTime.now().plusHours(4))
                .setTotalSeats(50)
                .build());

        AdvancedFilterService filterService = new AdvancedFilterService();

        // Test filter flights by date range
        List<Flight> filteredFlight = filterService.filterFlightsByDate(flight, LocalDateTime.now().minusHours(1), LocalDateTime.now().plusHours(2));
        assertEquals(1, filteredFlight.size());

        // Test filter flights by seat availability
        filteredFlight = filterService.filterFlightsBySeats(flight, 60);
        assertEquals(1, filteredFlight.size());
    }
}