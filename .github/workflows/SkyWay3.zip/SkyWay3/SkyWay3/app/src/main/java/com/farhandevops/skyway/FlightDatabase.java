package com.farhandevops.skyway;

import com.farhandevops.skyway.models.Flights;
import java.util.ArrayList;
import java.util.List;

public class FlightDatabase {

    public static List<Flights> generateMockFlights() {
        List<Flights> flights = new ArrayList<>();

        // International Flights
        flights.add(new Flights.Builder()
                .setFlightId("SK101")
                .setAirline("SkyWay Airlines")
                .setOrigin("New York")
                .setDestination("London")
                .setDepartureTime("08:00 AM")
                .setArrivalTime("06:00 PM")
                .setPrice(599.99)
                .setTotalSeats(150)
                .setFlightClass("Business")
                .setAircraftType("Boeing 787")
                .build());

        flights.add(new Flights.Builder()
                .setFlightId("SK102")
                .setAirline("SkyWay Airlines")
                .setOrigin("Paris")
                .setDestination("Dubai")
                .setDepartureTime("10:30 AM")
                .setArrivalTime("08:45 PM")
                .setPrice(749.50)
                .setTotalSeats(120)
                .setFlightClass("First Class")
                .setAircraftType("Airbus A380")
                .build());

        flights.add(new Flights.Builder()
                .setFlightId("SK103")
                .setAirline("SkyWay Airlines")
                .setOrigin("Tokyo")
                .setDestination("Sydney")
                .setDepartureTime("11:15 AM")
                .setArrivalTime("09:30 PM")
                .setPrice(899.75)
                .setTotalSeats(100)
                .setFlightClass("Economy")
                .setAircraftType("Boeing 777")
                .build());

        flights.add(new Flights.Builder()
                .setFlightId("SK104")
                .setAirline("SkyWay Airlines")
                .setOrigin("Los Angeles")
                .setDestination("Rome")
                .setDepartureTime("02:00 PM")
                .setArrivalTime("12:30 AM")
                .setPrice(899.00)
                .setTotalSeats(180)
                .setFlightClass("Business")
                .setAircraftType("Boeing 787")
                .build());

        flights.add(new Flights.Builder()
                .setFlightId("SK105")
                .setAirline("SkyWay Airlines")
                .setOrigin("San Francisco")
                .setDestination("Shanghai")
                .setDepartureTime("09:30 AM")
                .setArrivalTime("07:00 PM")
                .setPrice(799.99)
                .setTotalSeats(110)
                .setFlightClass("Economy")
                .setAircraftType("Airbus A350")
                .build());

        flights.add(new Flights.Builder()
                .setFlightId("SK106")
                .setAirline("SkyWay Airlines")
                .setOrigin("New York")
                .setDestination("Dubai")
                .setDepartureTime("03:00 PM")
                .setArrivalTime("11:30 PM")
                .setPrice(649.90)
                .setTotalSeats(160)
                .setFlightClass("First Class")
                .setAircraftType("Airbus A380")
                .build());

        flights.add(new Flights.Builder()
                .setFlightId("SK107")
                .setAirline("SkyWay Airlines")
                .setOrigin("Chicago")
                .setDestination("Tokyo")
                .setDepartureTime("06:30 AM")
                .setArrivalTime("04:30 PM")
                .setPrice(850.00)
                .setTotalSeats(130)
                .setFlightClass("Business")
                .setAircraftType("Boeing 787")
                .build());

        flights.add(new Flights.Builder()
                .setFlightId("SK108")
                .setAirline("SkyWay Airlines")
                .setOrigin("Los Angeles")
                .setDestination("Sydney")
                .setDepartureTime("10:00 AM")
                .setArrivalTime("08:00 PM")
                .setPrice(950.50)
                .setTotalSeats(140)
                .setFlightClass("First Class")
                .setAircraftType("Airbus A350")
                .build());

        flights.add(new Flights.Builder()
                .setFlightId("SK109")
                .setAirline("SkyWay Airlines")
                .setOrigin("Miami")
                .setDestination("London")
                .setDepartureTime("04:45 PM")
                .setArrivalTime("02:30 AM")
                .setPrice(550.00)
                .setTotalSeats(110)
                .setFlightClass("Economy")
                .setAircraftType("Boeing 777")
                .build());

        flights.add(new Flights.Builder()
                .setFlightId("SK110")
                .setAirline("SkyWay Airlines")
                .setOrigin("Paris")
                .setDestination("Singapore")
                .setDepartureTime("08:30 AM")
                .setArrivalTime("05:30 PM")
                .setPrice(999.99)
                .setTotalSeats(120)
                .setFlightClass("Business")
                .setAircraftType("Airbus A380")
                .build());

        // Domestic Flights
        flights.add(new Flights.Builder()
                .setFlightId("SK111")
                .setAirline("SkyWay Airlines")
                .setOrigin("New York")
                .setDestination("Los Angeles")
                .setDepartureTime("07:00 AM")
                .setArrivalTime("10:00 AM")
                .setPrice(199.99)
                .setTotalSeats(200)
                .setFlightClass("Economy")
                .setAircraftType("Boeing 737")
                .build());

        flights.add(new Flights.Builder()
                .setFlightId("SK112")
                .setAirline("SkyWay Airlines")
                .setOrigin("Chicago")
                .setDestination("San Francisco")
                .setDepartureTime("08:00 AM")
                .setArrivalTime("10:30 AM")
                .setPrice(220.00)
                .setTotalSeats(180)
                .setFlightClass("Business")
                .setAircraftType("Airbus A320")
                .build());

        flights.add(new Flights.Builder()
                .setFlightId("SK113")
                .setAirline("SkyWay Airlines")
                .setOrigin("Miami")
                .setDestination("Houston")
                .setDepartureTime("09:00 AM")
                .setArrivalTime("11:30 AM")
                .setPrice(150.00)
                .setTotalSeats(160)
                .setFlightClass("Economy")
                .setAircraftType("Boeing 737")
                .build());

        flights.add(new Flights.Builder()
                .setFlightId("SK114")
                .setAirline("SkyWay Airlines")
                .setOrigin("Boston")
                .setDestination("Dallas")
                .setDepartureTime("01:00 PM")
                .setArrivalTime("03:00 PM")
                .setPrice(180.50)
                .setTotalSeats(130)
                .setFlightClass("First Class")
                .setAircraftType("Airbus A320")
                .build());

        flights.add(new Flights.Builder()
                .setFlightId("SK115")
                .setAirline("SkyWay Airlines")
                .setOrigin("Seattle")
                .setDestination("Denver")
                .setDepartureTime("03:00 PM")
                .setArrivalTime("05:30 PM")
                .setPrice(210.00)
                .setTotalSeats(150)
                .setFlightClass("Economy")
                .setAircraftType("Boeing 737")
                .build());

        flights.add(new Flights.Builder()
                .setFlightId("SK116")
                .setAirline("SkyWay Airlines")
                .setOrigin("Chicago")
                .setDestination("Miami")
                .setDepartureTime("11:00 AM")
                .setArrivalTime("01:30 PM")
                .setPrice(170.00)
                .setTotalSeats(140)
                .setFlightClass("Economy")
                .setAircraftType("Airbus A320")
                .build());

        flights.add(new Flights.Builder()
                .setFlightId("SK117")
                .setAirline("SkyWay Airlines")
                .setOrigin("Los Angeles")
                .setDestination("San Francisco")
                .setDepartureTime("06:30 AM")
                .setArrivalTime("07:30 AM")
                .setPrice(90.00)
                .setTotalSeats(160)
                .setFlightClass("Economy")
                .setAircraftType("Boeing 737")
                .build());

        flights.add(new Flights.Builder()
                .setFlightId("SK118")
                .setAirline("SkyWay Airlines")
                .setOrigin("Dallas")
                .setDestination("New York")
                .setDepartureTime("04:00 PM")
                .setArrivalTime("06:30 PM")
                .setPrice(250.00)
                .setTotalSeats(190)
                .setFlightClass("First Class")
                .setAircraftType("Airbus A320")
                .build());

        flights.add(new Flights.Builder()
                .setFlightId("SK119")
                .setAirline("SkyWay Airlines")
                .setOrigin("San Francisco")
                .setDestination("Seattle")
                .setDepartureTime("08:00 AM")
                .setArrivalTime("10:00 AM")
                .setPrice(210.00)
                .setTotalSeats(120)
                .setFlightClass("Business")
                .setAircraftType("Boeing 737")
                .build());

        flights.add(new Flights.Builder()
                .setFlightId("SK120")
                .setAirline("SkyWay Airlines")
                .setOrigin("Los Angeles")
                .setDestination("Las Vegas")
                .setDepartureTime("02:00 PM")
                .setArrivalTime("03:00 PM")
                .setPrice(80.00)
                .setTotalSeats(170)
                .setFlightClass("Economy")
                .setAircraftType("Boeing 737")
                .build());

        return flights;
    }

    public static List<Flights> searchFlights(String departure, String arrival) {
        List<Flights> allFlights = generateMockFlights();
        List<Flights> matchedFlights = new ArrayList<>();

        for (Flights flight : allFlights) {
            if (flight.getOrigin().equalsIgnoreCase(departure) &&
                    flight.getDestination().equalsIgnoreCase(arrival)) {
                matchedFlights.add(flight);
            }
        }

        return matchedFlights;
    }

    public List<Flights> getAllFlights() {
        return java.util.Collections.emptyList();
    }

    public void deleteFlight(Flights selectedFlight) {
    }

    public void addFlight(Flights newFlight) {
    }

    public void updateFlight(Flights flight) {

    }
}
