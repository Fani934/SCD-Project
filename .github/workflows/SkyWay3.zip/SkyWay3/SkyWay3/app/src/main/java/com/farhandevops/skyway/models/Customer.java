package com.farhandevops.skyway.models;

public final class Customer {
    private final String customerId; // Har ek customer ka unique ID
    private final String name; // Customer ka naam
    private final String email; // Customer ka email address
    private final String phone; // Customer ka phone number

    // Private constructor jo sirf Builder class se call hota hai
    private Customer(Builder builder) {
        this.customerId = builder.customerId; // Builder se customerId set karna
        this.name = builder.name; // Builder se name set karna
        this.email = builder.email; // Builder se email set karna
        this.phone = builder.phone; // Builder se phone set karna
    }

    // Customer ID ko return karne wala method
    public String getCustomerId() {
        return customerId;
    }

    // Customer ka naam return karne wala method
    public String getName() {
        return name;
    }

    // Customer ka email return karne wala method
    public String getEmail() {
        return email;
    }

    // Customer ka phone number return karne wala method
    public String getPhone() {
        return phone;
    }

    // Static Builder class jo Customer ka object create karne ke liye hai
    public static class Builder {
        private String customerId; // Builder ka customerId
        private String name; // Builder ka name
        private String email; // Builder ka email
        private String phone; // Builder ka phone

        // Builder mein customerId set karne ka method
        public Builder setCustomerId(String customerId) {
            this.customerId = customerId;
            return this;
        }

        // Builder mein name set karne ka method
        public Builder setName(String name) {
            this.name = name;
            return this;
        }

        // Builder mein email set karne ka method
        public Builder setEmail(String email) {
            this.email = email;
            return this;
        }

        // Builder mein phone set karne ka method
        public Builder setPhone(String phone) {
            this.phone = phone;
            return this;
        }

        // Customer ka object build karke return karne ka method
        public Customer build() {
            return new Customer(this); // Naya Customer object return karna
        }
    }
}
