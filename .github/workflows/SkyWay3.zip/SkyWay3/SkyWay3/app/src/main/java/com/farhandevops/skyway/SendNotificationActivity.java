package com.farhandevops.skyway;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SendNotificationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_notification);

        EditText etNotificationMessage = findViewById(R.id.et_notification_message);
        Button btnSend = findViewById(R.id.btn_send);

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message = etNotificationMessage.getText().toString().trim();
                if (!message.isEmpty()) {
                    // Here you can handle sending the notification, such as through Firebase Cloud Messaging (FCM) or other services.
                    // For demonstration, just show a Toast message.
                    Toast.makeText(SendNotificationActivity.this, "Notification sent: " + message, Toast.LENGTH_SHORT).show();
                    finish(); // Close the activity after sending notification
                } else {
                    Toast.makeText(SendNotificationActivity.this, "Please enter a notification message", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
