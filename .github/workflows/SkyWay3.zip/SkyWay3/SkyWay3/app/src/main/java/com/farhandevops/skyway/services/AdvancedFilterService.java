package com.farhandevops.skyway.services;

import com.farhandevops.skyway.models.Flight;
import com.farhandevops.skyway.models.Ticket;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

public class AdvancedFilterService {

    // Tickets ko price range ke mutabiq filter karne ka method
    public List<Ticket<?>> filterTicketsByPrice(List<Ticket<?>> tickets, double minPrice, double maxPrice) {
        return tickets.stream() // Stream shuru karte hain list se
                .filter(ticket -> ticket.getPrice() >= minPrice && ticket.getPrice() <= maxPrice)
                // Har ticket ko check karte hain ke kya uska price specified range mein hai
                .collect(Collectors.toList()); // Filtered tickets ko ek list mein collect karte hain
    }

    // Flights ko departure date ke mutabiq filter karne ka method
    public List<Flight> filterFlightsByDate(List<Flight> flights, LocalDateTime startDate, LocalDateTime endDate) {
        return flights.stream() // Stream shuru karte hain list se
                .filter(flight -> !flight.getDepartureTime().isBefore(startDate) &&
                        // Check karte hain ke flight ka departure time specified start date ke baad hai
                        !flight.getDepartureTime().isAfter(endDate))
                // Aur specified end date se pehle hai
                .collect(Collectors.toList()); // Filtered flights ko ek list mein collect karte hain
    }

    // Flights ko available seats ke mutabiq filter karne ka method
    public List<Flight> filterFlightsBySeats(List<Flight> flights, int minSeats) {
        return flights.stream() // Stream shuru karte hain list se
                .filter(flight -> flight.getTotalSeats() >= minSeats)
                // Check karte hain ke flight mein kam az kam specified seats available hain
                .collect(Collectors.toList()); // Filtered flights ko ek list mein collect karte hain
    }
}
