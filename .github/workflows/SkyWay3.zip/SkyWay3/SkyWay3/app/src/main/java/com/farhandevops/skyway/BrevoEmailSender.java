package com.farhandevops.skyway;

import android.content.Context;
import android.widget.Toast;

import java.io.File;

import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class BrevoEmailSender {

    private static final String BASE_URL = "https://api.brevo.com/";
    private static final String API_KEY = "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";

    private Context context;

    public BrevoEmailSender(Context context) {
        this.context = context;
    }

    public void sendEmail(String fromEmail, String toEmail, String subject, String body, File pdfFile) {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        BrevoAPI brevoAPI = retrofit.create(BrevoAPI.class);

        // Create the email request
        EmailRequest emailRequest = new EmailRequest();
        emailRequest.setSender(new EmailRequest.Sender(fromEmail));  // Use the 'fromEmail' parameter
        emailRequest.setTo(new EmailRequest.Recipient[]{new EmailRequest.Recipient(toEmail)});
        emailRequest.setSubject(subject);
        emailRequest.setHtmlContent(body);

        // Prepare the attachment (assuming the file is hosted somewhere)
        String fileUrl = "your-file-url";  // Use the file URL after uploading it to a server.
        emailRequest.setAttachment(new EmailRequest.Attachment[]{
                new EmailRequest.Attachment(fileUrl, "application/pdf", "SkywayTicket.pdf")
        });

        // Send the email
        Call<Void> call = brevoAPI.sendEmail(API_KEY, emailRequest);  // Pass the API_KEY here
        call.enqueue(new retrofit2.Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, retrofit2.Response<Void> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(context, "Ticket sent to your email", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(context, "Failed to send email", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Toast.makeText(context, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
