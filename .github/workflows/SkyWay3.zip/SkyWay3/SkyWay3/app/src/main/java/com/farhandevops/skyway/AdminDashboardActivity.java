package com.farhandevops.skyway;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class AdminDashboardActivity extends AppCompatActivity {

    private Button btnBookFlight, btnCheckStatus, btnUserProfile, btnLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);

        btnBookFlight = findViewById(R.id.btn_book_flight);
        btnCheckStatus = findViewById(R.id.btn_check_status);
        btnUserProfile = findViewById(R.id.btn_user_profile);
        btnLogout = findViewById(R.id.btn_logout);

        // Open Flight Management
        btnBookFlight.setOnClickListener(view -> {
            Intent intent = new Intent(AdminDashboardActivity.this, FlightManagementActivity.class);
            startActivity(intent);
        });

        // Open Passenger Management
        btnCheckStatus.setOnClickListener(view -> {
            Intent intent = new Intent(AdminDashboardActivity.this, PassengerManagementActivity.class);
            startActivity(intent);
        });

        // Open Send Notification
        btnUserProfile.setOnClickListener(view -> {
            Intent intent = new Intent(AdminDashboardActivity.this, SendNotificationActivity.class);
            startActivity(intent);
        });

        // Logout functionality
        btnLogout.setOnClickListener(view -> {
            // Clear session or token if required
            // Example: SharedPreferences or Firebase logout
            Intent intent = new Intent(AdminDashboardActivity.this, LoginActivity.class);
            startActivity(intent);
            finish(); // Close current activity
        });
    }
}
