package com.farhandevops.skyway;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class PassengerManagementActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passenger_management);

        Button btnAddPassenger = findViewById(R.id.btn_add_passenger);
        Button btnRemovePassenger = findViewById(R.id.btn_remove_passenger);
        Button btnPassengerList = findViewById(R.id.btn_passenger_list);


        btnAddPassenger.setOnClickListener(v -> showPassengerDialog("Add Passenger"));
        btnRemovePassenger.setOnClickListener(v -> showPassengerDialog("Remove Passenger"));
        btnPassengerList.setOnClickListener(v -> showPassengerListDialog());

    }

    private void showPassengerDialog(String title) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = this.getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_passenger, null);
        builder.setView(dialogView)
                .setTitle(title)
                .setPositiveButton("Submit", (dialog, which) -> {
                    EditText etName = dialogView.findViewById(R.id.et_passenger_name);
                    EditText etAge = dialogView.findViewById(R.id.et_passenger_age);
                    EditText etEmail = dialogView.findViewById(R.id.et_passenger_email);

                    String name = etName.getText().toString();
                    String age = etAge.getText().toString();
                    String email = etEmail.getText().toString();

                    // Add or Remove logic based on title
                    if (title.equals("Add Passenger")) {
                        // Add passenger to the list
                        Toast.makeText(this, "Passenger Added: " + name, Toast.LENGTH_SHORT).show();
                    } else {
                        // Remove passenger from the list
                        Toast.makeText(this, "Passenger Removed: " + name, Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                .create()
                .show();
    }

    private void showPassengerListDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Passenger List");

        List<String> passengers = getRandomPassengers();
        ListView listView = new ListView(this);
        listView.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, passengers));

        builder.setView(listView)
                .setPositiveButton("Close", (dialog, which) -> dialog.dismiss())
                .create()
                .show();
    }

    private List<String> getRandomPassengers() {
        List<String> passengers = new ArrayList<>();
        String[] names = {"John Doe", "Jane Smith", "Mike Johnson", "Emily Davis", "Chris Brown"};
        Random random = new Random();

        for (int i = 0; i < 10; i++) {
            passengers.add(names[random.nextInt(names.length)] + ", Age: " + (random.nextInt(60) + 18) + ", Email: " + names[random.nextInt(names.length)].toLowerCase() + "@example.com");
        }

        return passengers;
    }

    private void showNotificationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = this.getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_notification, null);
        builder.setView(dialogView)
                .setTitle("Send Notification")
                .setPositiveButton("Send", (dialog, which) -> {
                    EditText etMessage = dialogView.findViewById(R.id.et_notification_message);
                    String message = etMessage.getText().toString();
                    Toast.makeText(this, "Notification Sent: " + message, Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                .create()
                .show();
    }
}
