package com.farhandevops.skyway.services;
import com.farhandevops.skyway.models.Ticket;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AnalyticsService {

    // Calculate total revenue
    public double calculateTotalRevenue(List<Ticket<?>> tickets) {
        return tickets.stream().mapToDouble(Ticket::getPrice).sum();
    }

    // Find the most booked flight
    public String findMostBookedFlight(List<Ticket<?>> tickets) {
        Map<String, Integer> flightCount = new HashMap<>();

        for (Ticket<?> ticket : tickets) {
            flightCount.put(ticket.getFlightId(), flightCount.getOrDefault(ticket.getFlightId(), 0) + 1);
        }

        return flightCount.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse("No bookings yet");
    }

    // Find the most frequent customer
    public String findMostFrequentCustomer(List<Ticket<?>> tickets) {
        Map<String, Integer> customerCount = new HashMap<>();

        for (Ticket<?> ticket : tickets) {
            String customerId = ticket.getPassengerInfo().toString();
            customerCount.put(customerId, customerCount.getOrDefault(customerId, 0) + 1);
        }

        return customerCount.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse("No customers yet");
    }
}