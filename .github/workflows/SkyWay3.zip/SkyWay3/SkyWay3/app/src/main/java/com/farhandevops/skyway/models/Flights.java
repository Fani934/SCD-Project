package com.farhandevops.skyway.models;

import java.io.Serializable;
import java.util.Objects;

// Flights class jo ek flight ki details ko represent karti hai aur Serializable interface implement karti hai
public class Flights implements Serializable {
    private String flightNumber; // Flight number
    private String airline; // Airline ka naam
    private String departureCity; // Departure city
    private String arrivalCity; // Arrival city
    private String departureTime; // Departure time
    private String arrivalTime; // Arrival time
    private double price; // Flight ka price
    private int availableSeats; // Available seats ki number
    private String flightClass; // Flight class (e.g., economy, business)
    private String aircraftType; // Aircraft type (e.g., Boeing 747)

    // Private constructor jo Builder class se call hota hai
    public Flights(Builder builder) {
        this.flightNumber = builder.flightNumber;
        this.airline = builder.airline;
        this.departureCity = builder.departureCity;
        this.arrivalCity = builder.arrivalCity;
        this.departureTime = builder.departureTime;
        this.arrivalTime = builder.arrivalTime;
        this.price = builder.price;
        this.availableSeats = builder.availableSeats;
        this.flightClass = builder.flightClass;
        this.aircraftType = builder.aircraftType;
    }

    // Constructor to set certain fields (currently empty)
    public Flights(String flightNo, String time, String date, String day) {
    }

    // Getters for different fields
    public String getFlightNumber() {
        return flightNumber;
    }

    public String getAirline() {
        return airline;
    }

    public String getDepartureCity() {
        return departureCity;
    }

    public String getArrivalCity() {
        return arrivalCity;
    }

    public String getDepartureTime() {
        return departureTime;
    }

    public String getArrivalTime() {
        return arrivalTime;
    }

    public double getPrice() {
        return price;
    }

    public int getAvailableSeats() {
        return availableSeats;
    }

    public String getFlightClass() {
        return flightClass;
    }

    public String getAircraftType() {
        return aircraftType;
    }

    // Additional getters
    public String getFlightId() {
        return flightNumber;
    }

    public int getTotalSeats() {
        return availableSeats;
    }

    public String getOrigin() {
        return departureCity;
    }

    public String getDestination() {
        return arrivalCity;
    }

    // Check if seats are available
    public boolean isAvailable() {
        return availableSeats > 0;
    }

    // Reduce available seats if possible
    public void reduceAvailableSeats(int seats) {
        if (availableSeats >= seats) {
            availableSeats -= seats;
        }
    }

    // Placeholder method for flight duration
    public String getFlightDuration() {
        return "Placeholder Duration";
    }

    // Check if flight is international
    public boolean isInternationalFlight() {
        return !departureCity.equals(arrivalCity);
    }

    // Get flight route
    public String getFlightRoute() {
        return departureCity + " → " + arrivalCity;
    }

    // Get formatted price
    public String getFormattedPrice() {
        return String.format("$%.2f", price);
    }

    // Override toString method
    @Override
    public String toString() {
        return airline + " - " + flightNumber +
                " (" + departureCity + " to " + arrivalCity + ")";
    }

    // Override equals method for object comparison
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Flights flights = (Flights) o;
        return Double.compare(flights.price, price) == 0 &&
                availableSeats == flights.availableSeats &&
                Objects.equals(flightNumber, flights.flightNumber) &&
                Objects.equals(airline, flights.airline) &&
                Objects.equals(departureCity, flights.departureCity) &&
                Objects.equals(arrivalCity, flights.arrivalCity) &&
                Objects.equals(departureTime, flights.departureTime) &&
                Objects.equals(arrivalTime, flights.arrivalTime) &&
                Objects.equals(flightClass, flights.flightClass) &&
                Objects.equals(aircraftType, flights.aircraftType);
    }

    // Override hashCode method
    @Override
    public int hashCode() {
        return Objects.hash(flightNumber, airline, departureCity, arrivalCity,
                departureTime, arrivalTime, price, availableSeats,
                flightClass, aircraftType);
    }

    // Unused methods
    public int getFlightNo() {
        return 0;
    }

    public int getTime() {
        return 0;
    }

    public int getDate() {
        return 0;
    }

    public int getDay() {
        return 0;
    }

    public void setFlightNo(String string) {
    }

    public void setTime(String string) {
    }

    public void setDate(String string) {
    }

    public void setDay(String string) {
    }

    // Builder class for constructing Flights objects
    public static class Builder {
        private String flightNumber;
        private String airline;
        private String departureCity;
        private String arrivalCity;
        private String departureTime;
        private String arrivalTime;
        private double price;
        private int availableSeats;
        private String flightClass;
        private String aircraftType;

        // Builder methods to set different fields
        public Builder setFlightId(String flightNumber) {
            this.flightNumber = flightNumber;
            return this;
        }

        public Builder setOrigin(String origin) {
            this.departureCity = origin;
            return this;
        }

        public Builder setDestination(String destination) {
            this.arrivalCity = destination;
            return this;
        }

        public Builder setDepartureTime(String departureTime) {
            this.departureTime = departureTime;
            return this;
        }

        public Builder setArrivalTime(String arrivalTime) {
            this.arrivalTime = arrivalTime;
            return this;
        }

        public Builder setTotalSeats(int totalSeats) {
            this.availableSeats = totalSeats;
            return this;
        }

        public Builder setFlightNumber(String flightNumber) {
            this.flightNumber = flightNumber;
            return this;
        }

        public Builder setAirline(String airline) {
            this.airline = airline;
            return this;
        }

        public Builder setPrice(double price) {
            this.price = price;
            return this;
        }

        public Builder setFlightClass(String flightClass) {
            this.flightClass = flightClass;
            return this;
        }

        public Builder setAircraftType(String aircraftType) {
            this.aircraftType = aircraftType;
            return this;
        }

        // Build method to create Flights object
        public Flights build() {
            return new Flights(this);
        }
    }
}
