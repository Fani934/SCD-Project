package com.farhandevops.skyway.tests;

import com.farhandevops.skyway.models.Flight;
import com.farhandevops.skyway.services.FlightDataUpdater;
import com.farhandevops.skyway.services.ResourceAllocator;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class MultithreadingAndDeadlockTest {

    @Test
    public void testFlightDataUpdater() throws InterruptedException {
        // Create test flights
        List<Flight> flights = new ArrayList<>();
        flights.add(new Flight.Builder()
                .setFlightId("FL123")
                .setOrigin("New York")
                .setDestination("Los Angeles")
                .setDepartureTime(LocalDateTime.now().plusHours(3))
                .setArrivalTime(LocalDateTime.now().plusHours(6))
                .setTotalSeats(100)
                .build());

        flights.add(new Flight.Builder()
                .setFlightId("FL456")
                .setOrigin("London")
                .setDestination("Paris")
                .setDepartureTime(LocalDateTime.now().plusHours(2))
                .setArrivalTime(LocalDateTime.now().plusHours(4))
                .setTotalSeats(50)
                .build());

        // Start FlightDataUpdater in a separate thread
        FlightDataUpdater updater = new FlightDataUpdater(flights);
        Thread updaterThread = new Thread(updater);
        updaterThread.start();

        // Let it run for 10 seconds
        Thread.sleep(10000);

        // Interrupt the thread to stop
        updaterThread.interrupt();
    }

    @Test
    public void testDeadlockSimulation() throws InterruptedException {
        ResourceAllocator allocator = new ResourceAllocator();

        // Start threads to simulate deadlock
        Thread thread1 = new Thread(allocator::method1);
        Thread thread2 = new Thread(allocator::method2);

        thread1.start();
        thread2.start();

        // Let threads run for a bit
        Thread.sleep(1000);

        System.out.println("Simulating deadlock resolved...");
        allocator.resolveDeadlock(); // Call the deadlock resolution method
    }
}