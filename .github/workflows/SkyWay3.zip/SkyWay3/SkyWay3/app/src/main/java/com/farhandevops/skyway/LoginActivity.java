package com.farhandevops.skyway;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.util.Patterns;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

public class LoginActivity extends AppCompatActivity {

    private TextInputEditText emailEditText, passwordEditText;
    private MaterialButton loginButton;
    private ImageButton googleLoginButton, facebookLoginButton, twitterLoginButton;
    private TextView forgotPasswordText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize UI components
        emailEditText = findViewById(R.id.emailEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);
        googleLoginButton = findViewById(R.id.googleLoginButton);
        facebookLoginButton = findViewById(R.id.facebookLoginButton);
        twitterLoginButton = findViewById(R.id.twitterLoginButton);
        forgotPasswordText = findViewById(R.id.forgotPasswordText);

        // Login button click listener
        loginButton.setOnClickListener(view -> {
            String email = emailEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter your email and password", Toast.LENGTH_SHORT).show();
            } else if (email.equals("Administrator") && password.equals("admin123")) {
                Toast.makeText(this, "Admin Login Successful", Toast.LENGTH_SHORT).show();
                navigateToAdminDashboard();
            } else if (!isValidEmail(email)) {
                showErrorMessage("Invalid Email", "Please enter a valid email address.");
            } else {
                // Navigate directly to homepage if email is valid
                Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();
                navigateToHomepage();
            }
        });

        // Forgot password listener
        forgotPasswordText.setOnClickListener(view -> {
            Intent intent = new Intent(LoginActivity.this, ForgotPasswordActivity.class);
            startActivity(intent);
        });

        // Social login button listeners
        googleLoginButton.setOnClickListener(view -> showLoginDialog("Google"));
        facebookLoginButton.setOnClickListener(view -> showLoginDialog("Facebook"));
        twitterLoginButton.setOnClickListener(view -> showLoginDialog("X"));
    }

    private void navigateToHomepage() {
        Intent intent = new Intent(LoginActivity.this, HomePageActivity.class);
        startActivity(intent);
        finish();
    }

    private void navigateToAdminDashboard() {
        Intent intent = new Intent(LoginActivity.this, AdminDashboardActivity.class);
        startActivity(intent);
        finish();
    }

    private boolean isValidEmail(String email) {
        return Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    private void showErrorMessage(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title)
                .setMessage(message)
                .setPositiveButton("OK", (dialog, which) -> dialog.dismiss())
                .show();
    }

    private void showLoginDialog(String platform) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Login with " + platform);

        // Set up the input fields
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 20, 50, 20);

        EditText usernameField = new EditText(this);
        usernameField.setHint(platform.equals("Google") ? "Gmail Address" :
                platform.equals("Facebook") ? "Facebook Username" : "X Handle");
        layout.addView(usernameField);

        EditText passwordField = new EditText(this);
        passwordField.setHint("Password");
        passwordField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        layout.addView(passwordField);

        builder.setView(layout);

        builder.setPositiveButton("Login", (dialog, which) -> {
            String username = usernameField.getText().toString();
            String password = passwordField.getText().toString();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            } else if (!isValidEmail(username)) {
                showErrorMessage("Invalid Username", "Please enter a valid username/email address.");
            } else {
                Toast.makeText(this, "Logged in to " + platform + " as " + username, Toast.LENGTH_SHORT).show();
                navigateToHomepage();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        builder.show();
    }
}
